-- MySQL dump 10.13  Distrib 8.0.45, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: techstore
-- ------------------------------------------------------
-- Server version	8.0.45

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auditoriacliente`
--

DROP TABLE IF EXISTS `auditoriacliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auditoriacliente` (
  `id_auditoria` int NOT NULL AUTO_INCREMENT,
  `id_cliente` int NOT NULL,
  `data_hora` datetime DEFAULT CURRENT_TIMESTAMP,
  `tipo_operacao` varchar(20) NOT NULL,
  PRIMARY KEY (`id_auditoria`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auditoriacliente`
--

LOCK TABLES `auditoriacliente` WRITE;
/*!40000 ALTER TABLE `auditoriacliente` DISABLE KEYS */;
INSERT INTO `auditoriacliente` VALUES (1,2,'2026-10-26 19:33:23','INSERT'),(2,3,'2026-10-26 19:39:36','INSERT'),(3,4,'2026-10-26 19:39:36','INSERT'),(4,5,'2026-10-27 22:08:44','INSERT'),(5,6,'2026-11-02 13:58:35','INSERT'),(6,7,'2026-11-02 14:26:39','INSERT');
/*!40000 ALTER TABLE `auditoriacliente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clientes`
--

DROP TABLE IF EXISTS `clientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clientes` (
  `id_cliente` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `telefone` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id_cliente`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clientes`
--

LOCK TABLES `clientes` WRITE;
/*!40000 ALTER TABLE `clientes` DISABLE KEYS */;
INSERT INTO `clientes` VALUES (2,'Carlos Silva','13 99999-9999'),(3,'Mariana Souza','13 88888-8888'),(6,'Larissa','13 9945-09821'),(7,'Ana','13 97543-6547');
/*!40000 ALTER TABLE `clientes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `garrafas_abertas`
--

DROP TABLE IF EXISTS `garrafas_abertas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `garrafas_abertas` (
  `id_garrafa_aberta` int NOT NULL AUTO_INCREMENT,
  `id_produto_garrafa` int NOT NULL,
  `data_abertura` datetime DEFAULT CURRENT_TIMESTAMP,
  `id_vendedor` int NOT NULL,
  `status` enum('ABERTA','VAZIA') NOT NULL DEFAULT 'ABERTA',
  PRIMARY KEY (`id_garrafa_aberta`),
  KEY `id_produto_garrafa` (`id_produto_garrafa`),
  KEY `fk_garrafa_vendedor` (`id_vendedor`),
  CONSTRAINT `fk_garrafa_vendedor` FOREIGN KEY (`id_vendedor`) REFERENCES `vendedores` (`id_vendedor`),
  CONSTRAINT `garrafas_abertas_ibfk_1` FOREIGN KEY (`id_produto_garrafa`) REFERENCES `produtos` (`id_produto`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `garrafas_abertas`
--

LOCK TABLES `garrafas_abertas` WRITE;
/*!40000 ALTER TABLE `garrafas_abertas` DISABLE KEYS */;
/*!40000 ALTER TABLE `garrafas_abertas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `itens_venda`
--

DROP TABLE IF EXISTS `itens_venda`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `itens_venda` (
  `id_item` int NOT NULL AUTO_INCREMENT,
  `id_venda` int NOT NULL,
  `id_produto` int NOT NULL,
  `quantidade` int NOT NULL,
  `preco_unitario` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id_item`),
  KEY `id_venda` (`id_venda`),
  KEY `fk_item_produto` (`id_produto`),
  CONSTRAINT `fk_item_produto` FOREIGN KEY (`id_produto`) REFERENCES `produtos` (`id_produto`),
  CONSTRAINT `itens_venda_ibfk_1` FOREIGN KEY (`id_venda`) REFERENCES `vendas` (`id_venda`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `itens_venda`
--

LOCK TABLES `itens_venda` WRITE;
/*!40000 ALTER TABLE `itens_venda` DISABLE KEYS */;
INSERT INTO `itens_venda` VALUES (1,3,1,1,120.00),(2,4,12,1,27.00),(3,5,2,1,70.00),(4,5,12,2,27.00),(5,5,14,3,20.00);
/*!40000 ALTER TABLE `itens_venda` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `produtos`
--

DROP TABLE IF EXISTS `produtos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `produtos` (
  `id_produto` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `preco` decimal(10,2) NOT NULL,
  `estoque` int DEFAULT NULL,
  `id_vendedor` int DEFAULT NULL,
  `tipo_produto` enum('GARRAFA','DOSE') NOT NULL DEFAULT 'GARRAFA',
  PRIMARY KEY (`id_produto`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `produtos`
--

LOCK TABLES `produtos` WRITE;
/*!40000 ALTER TABLE `produtos` DISABLE KEYS */;
INSERT INTO `produtos` VALUES (1,'Jack Daniel tradicional',120.00,49,9,'GARRAFA'),(2,'Sake',70.00,19,9,'GARRAFA'),(3,'Vodka Smirnoff',150.00,40,9,'GARRAFA'),(4,'Don Luiz',210.00,30,9,'GARRAFA'),(5,'Jose cuervo',180.00,35,9,'GARRAFA'),(6,'Johnnie Walker Red Label',200.00,67,9,'GARRAFA'),(7,'Skol beats garrafa',15.00,100,9,'GARRAFA'),(8,'Ice smirnoff limão ',10.00,100,9,'GARRAFA'),(9,'Dose Don Luiz',20.00,NULL,9,'DOSE'),(10,'Dose Jose Cuervo',30.00,NULL,9,'DOSE'),(11,'Dose Red Label',25.00,NULL,9,'DOSE'),(12,'Dose Jack tradicional',27.00,NULL,9,'DOSE'),(13,'Dose Sake',20.00,NULL,9,'DOSE'),(14,'Dose Vodka Smirnoff',20.00,NULL,9,'DOSE');
/*!40000 ALTER TABLE `produtos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `relacao_doses`
--

DROP TABLE IF EXISTS `relacao_doses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `relacao_doses` (
  `id_produto_dose` int NOT NULL,
  `id_produto_garrafa` int NOT NULL,
  `ml_por_dose` int NOT NULL DEFAULT '50',
  PRIMARY KEY (`id_produto_dose`),
  KEY `id_produto_garrafa` (`id_produto_garrafa`),
  CONSTRAINT `relacao_doses_ibfk_1` FOREIGN KEY (`id_produto_dose`) REFERENCES `produtos` (`id_produto`),
  CONSTRAINT `relacao_doses_ibfk_2` FOREIGN KEY (`id_produto_garrafa`) REFERENCES `produtos` (`id_produto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `relacao_doses`
--

LOCK TABLES `relacao_doses` WRITE;
/*!40000 ALTER TABLE `relacao_doses` DISABLE KEYS */;
INSERT INTO `relacao_doses` VALUES (9,4,50),(10,5,50),(11,6,50),(12,1,50),(13,2,50),(14,3,50);
/*!40000 ALTER TABLE `relacao_doses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vendas`
--

DROP TABLE IF EXISTS `vendas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vendas` (
  `id_venda` int NOT NULL AUTO_INCREMENT,
  `id_vendedor` int NOT NULL,
  `data_venda` datetime DEFAULT CURRENT_TIMESTAMP,
  `id_cliente` int DEFAULT NULL,
  `status` enum('PENDENTE','CONCLUIDO','CANCELADO') NOT NULL DEFAULT 'CONCLUIDO',
  PRIMARY KEY (`id_venda`),
  KEY `id_vendedor` (`id_vendedor`),
  KEY `fk_vendas_clientes` (`id_cliente`),
  CONSTRAINT `fk_vendas_clientes` FOREIGN KEY (`id_cliente`) REFERENCES `clientes` (`id_cliente`),
  CONSTRAINT `vendas_ibfk_1` FOREIGN KEY (`id_vendedor`) REFERENCES `vendedores` (`id_vendedor`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vendas`
--

LOCK TABLES `vendas` WRITE;
/*!40000 ALTER TABLE `vendas` DISABLE KEYS */;
INSERT INTO `vendas` VALUES (1,9,'2026-10-12 14:17:27',NULL,'CONCLUIDO'),(2,9,'2026-10-12 14:18:22',NULL,'CONCLUIDO'),(3,9,'2026-10-12 19:52:14',NULL,'CONCLUIDO'),(4,10,'2026-10-12 19:55:46',NULL,'CONCLUIDO'),(5,9,'2026-10-12 21:24:23',NULL,'CONCLUIDO');
/*!40000 ALTER TABLE `vendas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vendedores`
--

DROP TABLE IF EXISTS `vendedores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vendedores` (
  `id_vendedor` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `usuario` varchar(50) DEFAULT NULL,
  `senha_hash` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_vendedor`),
  UNIQUE KEY `usuario` (`usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vendedores`
--

LOCK TABLES `vendedores` WRITE;
/*!40000 ALTER TABLE `vendedores` DISABLE KEYS */;
INSERT INTO `vendedores` VALUES (9,'Vitoria cullen','Vitoria','$2a$10$eUSqBTdmmu0N/47r7T6tu.AiYvooHX8beC7LIpB9QVAH3btVKSnB2'),(10,'Alisson','Alisson',NULL);
/*!40000 ALTER TABLE `vendedores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `vw_detalhes_vendas`
--

DROP TABLE IF EXISTS `vw_detalhes_vendas`;
/*!50001 DROP VIEW IF EXISTS `vw_detalhes_vendas`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vw_detalhes_vendas` AS SELECT 
 1 AS `id_venda`,
 1 AS `nome_vendedor`,
 1 AS `data_venda`,
 1 AS `nome_produto`,
 1 AS `tipo_produto`,
 1 AS `quantidade`,
 1 AS `preco_unitario`,
 1 AS `subtotal`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vw_garrafas_abertas`
--

DROP TABLE IF EXISTS `vw_garrafas_abertas`;
/*!50001 DROP VIEW IF EXISTS `vw_garrafas_abertas`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vw_garrafas_abertas` AS SELECT 
 1 AS `id_garrafa_aberta`,
 1 AS `nome_garrafa`,
 1 AS `nome_vendedor`,
 1 AS `data_abertura`,
 1 AS `status`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vw_historico_garrafas`
--

DROP TABLE IF EXISTS `vw_historico_garrafas`;
/*!50001 DROP VIEW IF EXISTS `vw_historico_garrafas`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vw_historico_garrafas` AS SELECT 
 1 AS `id_garrafa_aberta`,
 1 AS `nome_garrafa`,
 1 AS `nome_vendedor`,
 1 AS `data_abertura`,
 1 AS `status`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vw_historico_vendas`
--

DROP TABLE IF EXISTS `vw_historico_vendas`;
/*!50001 DROP VIEW IF EXISTS `vw_historico_vendas`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vw_historico_vendas` AS SELECT 
 1 AS `id_venda`,
 1 AS `nome_vendedor`,
 1 AS `data_venda`,
 1 AS `produtos_diferentes`,
 1 AS `total_venda`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vw_pedidos_clientes`
--

DROP TABLE IF EXISTS `vw_pedidos_clientes`;
/*!50001 DROP VIEW IF EXISTS `vw_pedidos_clientes`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vw_pedidos_clientes` AS SELECT 
 1 AS `codigo_pedido`,
 1 AS `data_pedido`,
 1 AS `status`,
 1 AS `valor_total`,
 1 AS `nome_cliente`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vw_produtos_vendedores`
--

DROP TABLE IF EXISTS `vw_produtos_vendedores`;
/*!50001 DROP VIEW IF EXISTS `vw_produtos_vendedores`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vw_produtos_vendedores` AS SELECT 
 1 AS `nome_produto`,
 1 AS `preco`,
 1 AS `estoque`,
 1 AS `nome_vendedor`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `vw_detalhes_vendas`
--

/*!50001 DROP VIEW IF EXISTS `vw_detalhes_vendas`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_detalhes_vendas` AS select `v`.`id_venda` AS `id_venda`,`ve`.`nome` AS `nome_vendedor`,`v`.`data_venda` AS `data_venda`,`p`.`nome` AS `nome_produto`,`p`.`tipo_produto` AS `tipo_produto`,`iv`.`quantidade` AS `quantidade`,`iv`.`preco_unitario` AS `preco_unitario`,(`iv`.`quantidade` * `iv`.`preco_unitario`) AS `subtotal` from (((`vendas` `v` join `vendedores` `ve` on((`v`.`id_vendedor` = `ve`.`id_vendedor`))) join `itens_venda` `iv` on((`v`.`id_venda` = `iv`.`id_venda`))) join `produtos` `p` on((`iv`.`id_produto` = `p`.`id_produto`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_garrafas_abertas`
--

/*!50001 DROP VIEW IF EXISTS `vw_garrafas_abertas`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_garrafas_abertas` AS select `ga`.`id_garrafa_aberta` AS `id_garrafa_aberta`,`p`.`nome` AS `nome_garrafa`,`v`.`nome` AS `nome_vendedor`,`ga`.`data_abertura` AS `data_abertura`,`ga`.`status` AS `status` from ((`garrafas_abertas` `ga` join `produtos` `p` on((`ga`.`id_produto_garrafa` = `p`.`id_produto`))) join `vendedores` `v` on((`ga`.`id_vendedor` = `v`.`id_vendedor`))) where (`ga`.`status` = 'ABERTA') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_historico_garrafas`
--

/*!50001 DROP VIEW IF EXISTS `vw_historico_garrafas`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_historico_garrafas` AS select `ga`.`id_garrafa_aberta` AS `id_garrafa_aberta`,`p`.`nome` AS `nome_garrafa`,`v`.`nome` AS `nome_vendedor`,`ga`.`data_abertura` AS `data_abertura`,`ga`.`status` AS `status` from ((`garrafas_abertas` `ga` join `produtos` `p` on((`ga`.`id_produto_garrafa` = `p`.`id_produto`))) join `vendedores` `v` on((`ga`.`id_vendedor` = `v`.`id_vendedor`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_historico_vendas`
--

/*!50001 DROP VIEW IF EXISTS `vw_historico_vendas`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_historico_vendas` AS select `v`.`id_venda` AS `id_venda`,`ve`.`nome` AS `nome_vendedor`,`v`.`data_venda` AS `data_venda`,count(`iv`.`id_item`) AS `produtos_diferentes`,coalesce(sum((`iv`.`quantidade` * `iv`.`preco_unitario`)),0) AS `total_venda` from ((`vendas` `v` join `vendedores` `ve` on((`v`.`id_vendedor` = `ve`.`id_vendedor`))) left join `itens_venda` `iv` on((`v`.`id_venda` = `iv`.`id_venda`))) group by `v`.`id_venda`,`ve`.`nome`,`v`.`data_venda` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_pedidos_clientes`
--

/*!50001 DROP VIEW IF EXISTS `vw_pedidos_clientes`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_pedidos_clientes` AS select `v`.`id_venda` AS `codigo_pedido`,`v`.`data_venda` AS `data_pedido`,`v`.`status` AS `status`,coalesce(sum((`iv`.`quantidade` * `iv`.`preco_unitario`)),0) AS `valor_total`,coalesce(`c`.`nome`,'Cliente não informado') AS `nome_cliente` from ((`vendas` `v` left join `clientes` `c` on((`v`.`id_cliente` = `c`.`id_cliente`))) left join `itens_venda` `iv` on((`v`.`id_venda` = `iv`.`id_venda`))) group by `v`.`id_venda`,`v`.`data_venda`,`v`.`status`,`c`.`nome` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_produtos_vendedores`
--

/*!50001 DROP VIEW IF EXISTS `vw_produtos_vendedores`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_produtos_vendedores` AS select `p`.`nome` AS `nome_produto`,`p`.`preco` AS `preco`,`p`.`estoque` AS `estoque`,`v`.`nome` AS `nome_vendedor` from (`produtos` `p` left join `vendedores` `v` on((`p`.`id_vendedor` = `v`.`id_vendedor`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-02 16:24:26
